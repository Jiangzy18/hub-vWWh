"""数据类型定义。"""

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Literal, Optional


@dataclass
class Answer:
    content: str
    model: str
    created_at: float = field(default_factory=time.time)
    hit_count: int = 0
    meta: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "content": self.content,
            "model": self.model,
            "created_at": self.created_at,
            "hit_count": self.hit_count,
            "meta": self.meta,
            "embedding": self.embedding,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Answer":
        return cls(
            content=d.get("content", ""),
            model=d.get("model", ""),
            created_at=d.get("created_at", 0.0),
            hit_count=d.get("hit_count", 0),
            meta=d.get("meta", {}),
            embedding=d.get("embedding"),
        )


@dataclass
class Message:
    role: Literal["user", "assistant", "system", "tool"]
    content: str
    ts: float = field(default_factory=time.time)
    meta: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "role": self.role,
            "content": self.content,
            "ts": self.ts,
            "meta": self.meta,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Message":
        return cls(
            role=d.get("role", "user"),
            content=d.get("content", ""),
            ts=d.get("ts", 0.0),
            meta=d.get("meta", {}),
        )


@dataclass
class Intent:
    name: str
    slots: Dict[str, Any] = field(default_factory=dict)
    confidence: float = 0.0
    schema_version: str = "v1"
    model: str = ""
    created_at: float = field(default_factory=time.time)
    meta: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "slots": self.slots,
            "confidence": self.confidence,
            "schema_version": self.schema_version,
            "model": self.model,
            "created_at": self.created_at,
            "meta": self.meta,
            "embedding": self.embedding,
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Intent":
        return cls(
            name=d.get("name", ""),
            slots=d.get("slots", {}),
            confidence=d.get("confidence", 0.0),
            schema_version=d.get("schema_version", "v1"),
            model=d.get("model", ""),
            created_at=d.get("created_at", 0.0),
            meta=d.get("meta", {}),
            embedding=d.get("embedding"),
        )
