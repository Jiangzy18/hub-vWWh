"""意图识别结构缓存模块。"""

import json
import logging
from typing import List, Optional

import redis

from ..config import CacheConfig
from ..normalize import make_hash
from ..types import Intent
from ..vector import cosine_similarity

log = logging.getLogger(__name__)


class IntentModule:
    def __init__(self, redis_client: redis.Redis, config: CacheConfig):
        self.redis = redis_client
        self.config = config

    def _key(self, text: str, schema_version: str) -> str:
        h = make_hash(text, self.config.normalize_algo)
        return f"{self.config.key_prefix}:intent:{self.config.normalize_algo}:{schema_version}:{h}"

    def _pattern(self, schema_version: str) -> str:
        return f"{self.config.key_prefix}:intent:{self.config.normalize_algo}:{schema_version}:*"

    def query_intent(
        self,
        text: str,
        schema_version: Optional[str] = None,
        use_cache: bool = True,
    ) -> Optional[Intent]:
        if not use_cache or not self.config.module_enabled("intent"):
            return None
        schema_version = schema_version or self.config.intent_default_schema_version
        raw = self.redis.get(self._key(text, schema_version))
        if raw is None:
            return None
        try:
            return Intent.from_dict(json.loads(raw))
        except (json.JSONDecodeError, TypeError):
            return None

    def cache_intent(
        self,
        text: str,
        intent: Intent,
        schema_version: Optional[str] = None,
        ttl: Optional[int] = None,
    ) -> None:
        if not self.config.module_enabled("intent"):
            return
        sv = schema_version or intent.schema_version
        intent.schema_version = sv
        self.redis.set(
            self._key(text, sv),
            json.dumps(intent.to_dict()),
            ex=ttl or self.config.intent_ttl,
        )

    def query_intent_semantic(
        self,
        text: str,
        embedding: List[float],
        threshold: float = 0.90,
        schema_version: Optional[str] = None,
    ) -> Optional[Intent]:
        if not self.config.module_enabled("intent"):
            return None
        schema_version = schema_version or self.config.intent_default_schema_version
        best: Optional[Intent] = None
        best_score = -1.0
        try:
            for key in self.redis.scan_iter(match=self._pattern(schema_version), count=200):
                raw = self.redis.get(key)
                if raw is None:
                    continue
                try:
                    intent = Intent.from_dict(json.loads(raw))
                except (json.JSONDecodeError, TypeError):
                    continue
                if intent.embedding is None:
                    continue
                score = cosine_similarity(embedding, intent.embedding)
                if score >= threshold and score > best_score:
                    best = intent
                    best_score = score
        except redis.RedisError as e:
            log.warning("intent semantic scan failed: %s", e)
            return None
        return best
