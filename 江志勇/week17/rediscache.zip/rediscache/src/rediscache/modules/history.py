"""对话历史缓存模块。"""

import json
from typing import List, Literal, Optional

import redis

from ..config import CacheConfig
from ..types import Message


class HistoryModule:
    def __init__(self, redis_client: redis.Redis, config: CacheConfig):
        self.redis = redis_client
        self.config = config

    def _key(self, session_id: str) -> str:
        return f"{self.config.key_prefix}:hist:{session_id}"

    def query_history(
        self,
        session_id: str,
        limit: int = 20,
        order: Literal["asc", "desc"] = "asc",
        use_cache: bool = True,
    ) -> List[Message]:
        if not use_cache or not self.config.module_enabled("history"):
            return []
        key = self._key(session_id)
        if order == "asc":
            raws = self.redis.lrange(key, -limit, -1)
        else:
            raws = self.redis.lrange(key, 0, limit - 1)
        result: List[Message] = []
        for raw in raws:
            try:
                result.append(Message.from_dict(json.loads(raw)))
            except (json.JSONDecodeError, TypeError):
                continue
        return result

    def query_history_window(
        self,
        session_id: str,
        max_tokens: int = 4000,
    ) -> List[Message]:
        msgs = self.query_history(
            session_id,
            limit=self.config.max_history_len,
            order="asc",
        )
        selected: List[Message] = []
        total = 0
        for msg in reversed(msgs):
            tokens = max(len(msg.content) // 4, 1)
            if selected and total + tokens > max_tokens:
                break
            selected.append(msg)
            total += tokens
        return list(reversed(selected))

    def append_message(
        self,
        session_id: str,
        message: Message,
        ttl: Optional[int] = None,
    ) -> None:
        if not self.config.module_enabled("history"):
            return
        key = self._key(session_id)
        ttl = ttl or self.config.history_ttl
        pipe = self.redis.pipeline()
        pipe.rpush(key, json.dumps(message.to_dict()))
        pipe.ltrim(key, -self.config.max_history_len, -1)
        pipe.expire(key, ttl)
        pipe.execute()

    def clear_history(self, session_id: str) -> None:
        self.redis.delete(self._key(session_id))

    def extend_session_ttl(
        self,
        session_id: str,
        ttl: Optional[int] = None,
    ) -> None:
        self.redis.expire(self._key(session_id), ttl or self.config.history_ttl)

    def history_length(self, session_id: str) -> int:
        return int(self.redis.llen(self._key(session_id)) or 0)
