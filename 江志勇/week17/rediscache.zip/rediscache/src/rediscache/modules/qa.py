"""问答内容缓存模块。"""

import json
import logging
from typing import List, Optional

import redis

from ..config import CacheConfig
from ..normalize import make_hash
from ..types import Answer
from ..vector import cosine_similarity

log = logging.getLogger(__name__)


class QAModule:
    HASH_FIELDS = ("content", "model", "created_at", "hit_count", "meta", "embedding")

    def __init__(self, redis_client: redis.Redis, config: CacheConfig):
        self.redis = redis_client
        self.config = config

    def _key(self, text: str) -> str:
        h = make_hash(text, self.config.normalize_algo)
        return f"{self.config.key_prefix}:qa:{self.config.normalize_algo}:{h}"

    def _pattern(self) -> str:
        return f"{self.config.key_prefix}:qa:{self.config.normalize_algo}:*"

    def _answer_from_hash(self, h: dict) -> Optional[Answer]:
        if not h:
            return None
        try:
            return Answer.from_dict(
                {
                    "content": h.get("content", ""),
                    "model": h.get("model", ""),
                    "created_at": float(h.get("created_at", 0.0)),
                    "hit_count": int(h.get("hit_count", 0)),
                    "meta": json.loads(h.get("meta", "{}")) if h.get("meta") else {},
                    "embedding": json.loads(h.get("embedding", "null"))
                    if h.get("embedding")
                    else None,
                }
            )
        except (json.JSONDecodeError, TypeError, ValueError):
            return None

    def query_answer(
        self,
        question: str,
        use_cache: bool = True,
        track_hit: bool = True,
    ) -> Optional[Answer]:
        if not use_cache or not self.config.module_enabled("qa"):
            return None
        key = self._key(question)
        h = self.redis.hgetall(key)
        answer = self._answer_from_hash(h)
        if answer is None:
            return None
        if track_hit:
            try:
                self.redis.hincrby(key, "hit_count", 1)
            except redis.RedisError as e:
                log.warning("hit_count increment failed: %s", e)
        return answer

    def cache_answer(
        self,
        question: str,
        answer: Answer,
        embedding: Optional[List[float]] = None,
        ttl: Optional[int] = None,
    ) -> None:
        if not self.config.module_enabled("qa"):
            return
        if embedding is not None:
            answer.embedding = embedding
        key = self._key(question)
        mapping = {
            "content": answer.content,
            "model": answer.model,
            "created_at": str(answer.created_at),
            "hit_count": str(answer.hit_count),
            "meta": json.dumps(answer.meta),
            "embedding": json.dumps(answer.embedding) if answer.embedding is not None else "",
        }
        pipe = self.redis.pipeline()
        pipe.hset(key, mapping=mapping)
        pipe.expire(key, ttl or self.config.qa_ttl)
        pipe.execute()

    def cache_answer_with_embedding(
        self,
        question: str,
        answer: Answer,
        embedding: List[float],
        ttl: Optional[int] = None,
    ) -> None:
        self.cache_answer(question, answer, embedding=embedding, ttl=ttl)

    def query_answer_semantic(
        self,
        question: str,
        embedding: List[float],
        threshold: float = 0.92,
        top_k: int = 1,
    ) -> Optional[Answer]:
        if not self.config.module_enabled("qa"):
            return None
        scored: List[tuple] = []
        try:
            for key in self.redis.scan_iter(match=self._pattern(), count=200):
                h = self.redis.hgetall(key)
                if not h:
                    continue
                emb_raw = h.get("embedding")
                if not emb_raw:
                    continue
                try:
                    emb = json.loads(emb_raw)
                except (json.JSONDecodeError, TypeError):
                    continue
                score = cosine_similarity(embedding, emb)
                if score < threshold:
                    continue
                answer = self._answer_from_hash(h)
                if answer is not None:
                    scored.append((score, answer))
        except redis.RedisError as e:
            log.warning("qa semantic scan failed: %s", e)
            return None
        if not scored:
            return None
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored[0][1]
