"""编码缓存模块。"""

import json
from typing import List, Optional

import redis

from ..config import CacheConfig
from ..normalize import make_hash


class EncodingModule:
    def __init__(self, redis_client: redis.Redis, config: CacheConfig):
        self.redis = redis_client
        self.config = config

    def _key(self, text: str, model: str) -> str:
        h = make_hash(text, self.config.normalize_algo)
        return f"{self.config.key_prefix}:enc:{model}:{h}"

    def query_encoding(
        self,
        text: str,
        model: Optional[str] = None,
        use_cache: bool = True,
    ) -> Optional[List[float]]:
        if not use_cache or not self.config.module_enabled("encoding"):
            return None
        model = model or self.config.encoding_default_model
        raw = self.redis.get(self._key(text, model))
        if raw is None:
            return None
        try:
            return json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return None

    def cache_encoding(
        self,
        text: str,
        embedding: List[float],
        model: Optional[str] = None,
        ttl: Optional[int] = None,
    ) -> None:
        if not self.config.module_enabled("encoding"):
            return
        model = model or self.config.encoding_default_model
        self.redis.set(
            self._key(text, model),
            json.dumps(embedding),
            ex=ttl or self.config.encoding_ttl,
        )

    def batch_query_encodings(
        self,
        texts: List[str],
        model: Optional[str] = None,
    ) -> List[Optional[List[float]]]:
        if not texts or not self.config.module_enabled("encoding"):
            return [None] * len(texts)
        model = model or self.config.encoding_default_model
        keys = [self._key(t, model) for t in texts]
        raws = self.redis.mget(keys)
        results: List[Optional[List[float]]] = []
        for raw in raws:
            if raw is None:
                results.append(None)
            else:
                try:
                    results.append(json.loads(raw))
                except (json.JSONDecodeError, TypeError):
                    results.append(None)
        return results

    def batch_cache_encodings(
        self,
        texts: List[str],
        embeddings: List[List[float]],
        model: Optional[str] = None,
        ttl: Optional[int] = None,
    ) -> None:
        if not texts or not self.config.module_enabled("encoding"):
            return
        if len(texts) != len(embeddings):
            raise ValueError("texts and embeddings must have the same length")
        model = model or self.config.encoding_default_model
        ttl = ttl or self.config.encoding_ttl
        pipe = self.redis.pipeline()
        for text, emb in zip(texts, embeddings):
            pipe.set(self._key(text, model), json.dumps(emb), ex=ttl)
        pipe.execute()
