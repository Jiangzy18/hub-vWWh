"""归一化与 hash 工具。"""

import hashlib
import re

_PUNCT_TAIL = re.compile(r"[。.!?,;:？!，,；：]+$")
_WHITESPACE = re.compile(r"\s+")


def normalize(text: str) -> str:
    text = text.strip().lower()
    text = _WHITESPACE.sub(" ", text)
    text = _PUNCT_TAIL.sub("", text)
    return text


def make_hash(text: str, algo: str = "norm-v1") -> str:
    return hashlib.sha1(f"{algo}:{normalize(text)}".encode("utf-8")).hexdigest()
