"""CacheConfig — 集中所有可调参数，禁止在业务代码里散落魔法值。"""

from dataclasses import dataclass


@dataclass
class CacheConfig:
    redis_url: str = "redis://localhost:6379/0"

    key_prefix: str = "rc"

    qa_ttl: int = 86400
    encoding_ttl: int = 2592000
    history_ttl: int = 7200
    intent_ttl: int = 604800

    normalize_algo: str = "norm-v1"

    max_history_len: int = 1000

    enabled: bool = True
    enable_qa: bool = True
    enable_encoding: bool = True
    enable_history: bool = True
    enable_intent: bool = True

    encoding_default_model: str = "text-embedding-3-small"
    intent_default_schema_version: str = "v1"

    def module_enabled(self, module: str) -> bool:
        return self.enabled and getattr(self, f"enable_{module}", True)
