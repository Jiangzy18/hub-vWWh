"""RedisCache — 统一缓存入口。"""

from dataclasses import dataclass
from typing import Any, Dict, List, Literal, Optional

import redis

from .config import CacheConfig
from .modules.encoding import EncodingModule
from .modules.history import HistoryModule
from .modules.intent import IntentModule
from .modules.qa import QAModule
from .types import Answer, Intent, Message


@dataclass
class CacheStats:
    qa_hits: int = 0
    qa_misses: int = 0
    encoding_hits: int = 0
    encoding_misses: int = 0
    intent_hits: int = 0
    intent_misses: int = 0
    history_queries: int = 0


class RedisCache:
    def __init__(self, redis_client: redis.Redis, config: Optional[CacheConfig] = None):
        self.redis = redis_client
        self.config = config or CacheConfig()
        self._encoding = EncodingModule(redis_client, self.config)
        self._history = HistoryModule(redis_client, self.config)
        self._intent = IntentModule(redis_client, self.config)
        self._qa = QAModule(redis_client, self.config)
        self._stats = CacheStats()

    @classmethod
    def from_url(cls, url: str, config: Optional[CacheConfig] = None, **kwargs) -> "RedisCache":
        client = redis.Redis.from_url(url, decode_responses=True, **kwargs)
        return cls(client, config=config)

    @property
    def encoding(self) -> EncodingModule:
        return self._encoding

    @property
    def history(self) -> HistoryModule:
        return self._history

    @property
    def intent(self) -> IntentModule:
        return self._intent

    @property
    def qa(self) -> QAModule:
        return self._qa

    def query_answer(
        self,
        question: str,
        use_cache: bool = True,
    ) -> Optional[Answer]:
        result = self._qa.query_answer(question, use_cache=use_cache)
        if result is not None:
            self._stats.qa_hits += 1
        else:
            self._stats.qa_misses += 1
        return result

    def query_answer_semantic(
        self,
        question: str,
        embedding: List[float],
        threshold: float = 0.92,
    ) -> Optional[Answer]:
        result = self._qa.query_answer_semantic(
            question, embedding, threshold=threshold
        )
        if result is not None:
            self._stats.qa_hits += 1
        else:
            self._stats.qa_misses += 1
        return result

    def query_encoding(
        self,
        text: str,
        model: Optional[str] = None,
        use_cache: bool = True,
    ) -> Optional[List[float]]:
        result = self._encoding.query_encoding(text, model=model, use_cache=use_cache)
        if result is not None:
            self._stats.encoding_hits += 1
        else:
            self._stats.encoding_misses += 1
        return result

    def query_history(
        self,
        session_id: str,
        limit: int = 20,
        order: Literal["asc", "desc"] = "asc",
        use_cache: bool = True,
    ) -> List[Message]:
        self._stats.history_queries += 1
        return self._history.query_history(session_id, limit=limit, order=order, use_cache=use_cache)

    def query_history_window(
        self,
        session_id: str,
        max_tokens: int = 4000,
    ) -> List[Message]:
        self._stats.history_queries += 1
        return self._history.query_history_window(session_id, max_tokens=max_tokens)

    def query_intent(
        self,
        text: str,
        schema_version: Optional[str] = None,
        use_cache: bool = True,
    ) -> Optional[Intent]:
        result = self._intent.query_intent(text, schema_version=schema_version, use_cache=use_cache)
        if result is not None:
            self._stats.intent_hits += 1
        else:
            self._stats.intent_misses += 1
        return result

    def query_intent_semantic(
        self,
        text: str,
        embedding: List[float],
        threshold: float = 0.90,
        schema_version: Optional[str] = None,
    ) -> Optional[Intent]:
        result = self._intent.query_intent_semantic(
            text, embedding, threshold=threshold, schema_version=schema_version
        )
        if result is not None:
            self._stats.intent_hits += 1
        else:
            self._stats.intent_misses += 1
        return result

    def cache_answer(
        self,
        question: str,
        answer: Answer,
        embedding: Optional[List[float]] = None,
    ) -> None:
        self._qa.cache_answer(question, answer, embedding=embedding)

    def cache_answer_with_embedding(
        self,
        question: str,
        answer: Answer,
        embedding: List[float],
    ) -> None:
        self._qa.cache_answer_with_embedding(question, answer, embedding)

    def cache_encoding(
        self,
        text: str,
        embedding: List[float],
        model: Optional[str] = None,
    ) -> None:
        self._encoding.cache_encoding(text, embedding, model=model)

    def batch_query_encodings(
        self,
        texts: List[str],
        model: Optional[str] = None,
    ) -> List[Optional[List[float]]]:
        return self._encoding.batch_query_encodings(texts, model=model)

    def batch_cache_encodings(
        self,
        texts: List[str],
        embeddings: List[List[float]],
        model: Optional[str] = None,
    ) -> None:
        self._encoding.batch_cache_encodings(texts, embeddings, model=model)

    def append_message(self, session_id: str, message: Message) -> None:
        self._history.append_message(session_id, message)

    def clear_history(self, session_id: str) -> None:
        self._history.clear_history(session_id)

    def cache_intent(
        self,
        text: str,
        intent: Intent,
        schema_version: Optional[str] = None,
    ) -> None:
        self._intent.cache_intent(text, intent, schema_version=schema_version)

    def cache_intent_with_embedding(
        self,
        text: str,
        intent: Intent,
        embedding: List[float],
        schema_version: Optional[str] = None,
    ) -> None:
        self._intent.cache_intent(
            text, intent, schema_version=schema_version
        )
        intent.embedding = embedding
        self._intent.cache_intent(text, intent, schema_version=schema_version or intent.schema_version)

    def stats(self) -> CacheStats:
        return self._stats

    def reset_stats(self) -> None:
        self._stats = CacheStats()

    def health(self) -> bool:
        try:
            return bool(self.redis.ping())
        except redis.RedisError:
            return False
