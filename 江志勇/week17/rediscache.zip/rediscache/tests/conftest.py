"""conftest — 共享 fixture。"""

import pytest
import fakeredis

from rediscache import CacheConfig, RedisCache


@pytest.fixture
def redis_client():
    return fakeredis.FakeRedis(decode_responses=True)


@pytest.fixture
def config():
    return CacheConfig(
        redis_url="redis://localhost:6379/0",
        key_prefix="test",
    )


@pytest.fixture
def cache(redis_client, config):
    return RedisCache(redis_client, config)
