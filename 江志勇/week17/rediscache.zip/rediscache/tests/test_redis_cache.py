"""RedisCache 统一入口测试。"""

from rediscache import Answer, Intent, Message, RedisCache


def test_health(cache: RedisCache):
    assert cache.health() is True


def test_reset_stats(cache: RedisCache):
    cache.query_answer("miss")
    cache.reset_stats()
    assert cache.stats().qa_misses == 0


def test_end_to_end_qa(cache: RedisCache):
    ans = cache.query_answer("什么是 Redis？")
    assert ans is None
    cache.cache_answer("什么是 Redis？", Answer(content="内存数据库", model="gpt-4"))
    ans = cache.query_answer("什么是 Redis？")
    assert ans.content == "内存数据库"


def test_end_to_end_history(cache: RedisCache):
    sid = "user-1"
    cache.append_message(sid, Message(role="user", content="hi"))
    cache.append_message(sid, Message(role="assistant", content="hello"))
    msgs = cache.query_history(sid)
    assert [m.content for m in msgs] == ["hi", "hello"]


def test_end_to_end_intent(cache: RedisCache):
    intent = Intent(name="订机票", slots={"from": "上海"}, confidence=0.88)
    cache.cache_intent("订一张从上海出发的机票", intent)
    got = cache.query_intent("订一张从上海出发的机票")
    assert got.slots == {"from": "上海"}


def test_end_to_end_encoding(cache: RedisCache):
    emb = [0.1] * 8
    cache.cache_encoding("hello", emb)
    assert cache.query_encoding("hello") == emb


def test_from_url(config):
    cache = RedisCache.from_url("redis://localhost:6379/0", config=config)
    assert cache.config is config
