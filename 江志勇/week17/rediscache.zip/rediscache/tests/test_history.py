"""对话历史测试。"""

from rediscache import Message, RedisCache


def test_query_empty(cache: RedisCache):
    assert cache.query_history("s1") == []


def test_append_and_query_asc(cache: RedisCache):
    cache.append_message("s1", Message(role="user", content="hi"))
    cache.append_message("s1", Message(role="assistant", content="hello"))
    msgs = cache.query_history("s1")
    assert len(msgs) == 2
    assert msgs[0].content == "hi"
    assert msgs[1].content == "hello"


def test_query_desc(cache: RedisCache):
    for i in range(5):
        cache.append_message("s1", Message(role="user", content=f"m{i}"))
    msgs = cache.query_history("s1", limit=3, order="desc")
    assert [m.content for m in msgs] == ["m0", "m1", "m2"]


def test_query_limit(cache: RedisCache):
    for i in range(10):
        cache.append_message("s1", Message(role="user", content=f"m{i}"))
    msgs = cache.query_history("s1", limit=3)
    assert [m.content for m in msgs] == ["m7", "m8", "m9"]


def test_clear(cache: RedisCache):
    cache.append_message("s1", Message(role="user", content="x"))
    cache.clear_history("s1")
    assert cache.query_history("s1") == []


def test_max_length_trim(cache: RedisCache):
    cache.config.max_history_len = 5
    for i in range(10):
        cache.append_message("s1", Message(role="user", content=f"m{i}"))
    assert cache.history.history_length("s1") == 5
    msgs = cache.query_history("s1")
    assert [m.content for m in msgs] == ["m5", "m6", "m7", "m8", "m9"]


def test_window_limits_by_token(cache: RedisCache):
    for i in range(20):
        cache.append_message("s1", Message(role="user", content="x" * 40))
    msgs = cache.query_history_window("s1", max_tokens=50)
    total = sum(max(len(m.content) // 4, 1) for m in msgs)
    assert total <= 50
    assert len(msgs) <= 20


def test_window_returns_empty_when_no_history(cache: RedisCache):
    assert cache.query_history_window("s1") == []


def test_use_cache_false(cache: RedisCache):
    cache.append_message("s1", Message(role="user", content="x"))
    assert cache.query_history("s1", use_cache=False) == []


def test_disabled_module(cache: RedisCache):
    cache.config.enable_history = False
    cache.append_message("s1", Message(role="user", content="x"))
    assert cache.query_history("s1") == []


def test_stats_query_count(cache: RedisCache):
    cache.query_history("s1")
    cache.query_history("s2")
    assert cache.stats().history_queries == 2
