"""问答缓存测试。"""

from rediscache import Answer, RedisCache


def test_query_miss(cache: RedisCache):
    assert cache.query_answer("什么是 Python？") is None


def test_cache_and_query(cache: RedisCache):
    ans = Answer(content="Python 是一门编程语言。", model="gpt-4", meta={"tokens": 20})
    cache.cache_answer("什么是 Python？", ans)
    got = cache.query_answer("什么是 Python？")
    assert got is not None
    assert got.content == "Python 是一门编程语言。"
    assert got.model == "gpt-4"
    assert got.meta == {"tokens": 20}


def test_normalization(cache: RedisCache):
    ans = Answer(content="ok", model="gpt-4")
    cache.cache_answer("什么是 Python？", ans)
    assert cache.query_answer("  什么是 python？") is not None


def test_use_cache_false(cache: RedisCache):
    cache.cache_answer("q", Answer(content="a", model="m"))
    assert cache.query_answer("q", use_cache=False) is None


def test_disabled_module(cache: RedisCache):
    cache.config.enable_qa = False
    cache.cache_answer("q", Answer(content="a", model="m"))
    assert cache.query_answer("q") is None


def test_hit_count_increments(cache: RedisCache):
    ans = Answer(content="a", model="m")
    cache.cache_answer("q", ans)
    cache.query_answer("q")
    cache.query_answer("q")
    cache.query_answer("q")
    got = cache.query_answer("q", track_hit=False)
    assert got.hit_count == 3


def test_stats(cache: RedisCache):
    cache.query_answer("miss")
    cache.cache_answer("hit", Answer(content="a", model="m"))
    cache.query_answer("hit")
    s = cache.stats()
    assert s.qa_hits == 1
    assert s.qa_misses == 1


def test_semantic_hit(cache: RedisCache):
    q1 = [1.0, 0.0, 0.0]
    q2 = [0.98, 0.2, 0.0]
    cache.cache_answer_with_embedding(
        "什么是 Python？", Answer(content="一门语言", model="gpt-4"), embedding=q1
    )
    got = cache.query_answer_semantic("Python 是什么", q2, threshold=0.9)
    assert got is not None
    assert got.content == "一门语言"


def test_semantic_miss_no_embedding(cache: RedisCache):
    cache.cache_answer("q", Answer(content="a", model="m"))
    assert cache.query_answer_semantic("q", [1.0, 0.0, 0.0]) is None
