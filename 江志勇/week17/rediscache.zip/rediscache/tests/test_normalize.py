"""归一化与向量工具测试。"""

import math

from rediscache.normalize import make_hash, normalize
from rediscache.vector import cosine_similarity


def test_normalize_basic():
    assert normalize("Hello World") == "hello world"
    assert normalize("  hello   world  ") == "hello world"


def test_normalize_strips_trailing_punct():
    assert normalize("你好。") == "你好"
    assert normalize("what?") == "what"
    assert normalize("ok!!") == "ok"
    assert normalize("x,;") == "x"


def test_normalize_keeps_internal_punct():
    assert normalize("hi, there") == "hi, there"


def test_make_hash_stable():
    h1 = make_hash("Hello World")
    h2 = make_hash("  hello world  ")
    h3 = make_hash("hello world")
    assert h1 == h2 == h3


def test_make_hash_changes_with_algo():
    h1 = make_hash("hello", algo="norm-v1")
    h2 = make_hash("hello", algo="norm-v2")
    assert h1 != h2


def test_cosine_similarity_identical():
    a = [1.0, 2.0, 3.0]
    assert math.isclose(cosine_similarity(a, a), 1.0, rel_tol=1e-9)


def test_cosine_similarity_orthogonal():
    assert math.isclose(cosine_similarity([1.0, 0.0], [0.0, 1.0]), 0.0)


def test_cosine_similarity_different_lengths():
    assert cosine_similarity([1.0, 2.0], [1.0, 2.0, 3.0]) == 0.0


def test_cosine_similarity_zero_vector():
    assert cosine_similarity([0.0, 0.0], [1.0, 2.0]) == 0.0
