"""编码缓存测试。"""

from rediscache import RedisCache


def test_query_encoding_miss(cache: RedisCache):
    assert cache.query_encoding("hello") is None


def test_cache_and_query(cache: RedisCache):
    emb = [0.1, 0.2, 0.3]
    cache.cache_encoding("hello", emb)
    assert cache.query_encoding("hello") == emb


def test_query_use_cache_false(cache: RedisCache):
    cache.cache_encoding("hello", [0.1])
    assert cache.query_encoding("hello", use_cache=False) is None


def test_batch_query_encodings(cache: RedisCache):
    cache.cache_encoding("a", [0.1])
    cache.cache_encoding("b", [0.2])
    res = cache.batch_query_encodings(["a", "b", "c"])
    assert res == [[0.1], [0.2], None]


def test_batch_cache_encodings(cache: RedisCache):
    cache.batch_cache_encodings(["x", "y"], [[0.5], [0.6]])
    assert cache.query_encoding("x") == [0.5]
    assert cache.query_encoding("y") == [0.6]


def test_batch_cache_encodings_length_mismatch(cache: RedisCache):
    import pytest
    with pytest.raises(ValueError):
        cache.batch_cache_encodings(["a", "b"], [[0.1]])


def test_model_isolation(cache: RedisCache):
    cache.cache_encoding("hi", [0.1], model="model-a")
    cache.cache_encoding("hi", [0.2], model="model-b")
    assert cache.query_encoding("hi", model="model-a") == [0.1]
    assert cache.query_encoding("hi", model="model-b") == [0.2]


def test_normalization_groups_equivalent(cache: RedisCache):
    cache.cache_encoding("Hello World", [1.0])
    assert cache.query_encoding("  hello world  ") == [1.0]


def test_disabled_module(cache: RedisCache):
    cache.encoding.config.enable_encoding = False
    cache.cache_encoding("hi", [0.1])
    assert cache.query_encoding("hi") is None


def test_stats_increment(cache: RedisCache):
    cache.query_encoding("miss")
    cache.cache_encoding("hit", [0.1])
    cache.query_encoding("hit")
    s = cache.stats()
    assert s.encoding_hits == 1
    assert s.encoding_misses == 1
