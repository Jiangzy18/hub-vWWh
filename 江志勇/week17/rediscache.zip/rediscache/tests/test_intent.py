"""意图识别缓存测试。"""

from rediscache import Intent, RedisCache


def test_query_miss(cache: RedisCache):
    assert cache.query_intent("订一张去北京的机票") is None


def test_cache_and_query(cache: RedisCache):
    intent = Intent(name="订机票", slots={"destination": "北京"}, confidence=0.95, model="gpt-4")
    cache.cache_intent("订一张去北京的机票", intent)
    got = cache.query_intent("订一张去北京的机票")
    assert got is not None
    assert got.name == "订机票"
    assert got.slots == {"destination": "北京"}
    assert got.confidence == 0.95


def test_normalization(cache: RedisCache):
    intent = Intent(name="查天气", slots={"city": "北京"}, confidence=0.9)
    cache.cache_intent("北京天气", intent)
    got = cache.query_intent("  北京天气。")
    assert got is not None
    assert got.name == "查天气"


def test_schema_version_isolation(cache: RedisCache):
    v1 = Intent(name="旧意图", schema_version="v1")
    v2 = Intent(name="新意图", schema_version="v2")
    cache.cache_intent("文本", v1, schema_version="v1")
    cache.cache_intent("文本", v2, schema_version="v2")
    assert cache.query_intent("文本", schema_version="v1").name == "旧意图"
    assert cache.query_intent("文本", schema_version="v2").name == "新意图"


def test_use_cache_false(cache: RedisCache):
    intent = Intent(name="x")
    cache.cache_intent("text", intent)
    assert cache.query_intent("text", use_cache=False) is None


def test_disabled_module(cache: RedisCache):
    cache.config.enable_intent = False
    cache.cache_intent("text", Intent(name="x"))
    assert cache.query_intent("text") is None


def test_stats_intent(cache: RedisCache):
    cache.query_intent("miss")
    intent = Intent(name="x")
    cache.cache_intent("hit", intent)
    cache.query_intent("hit")
    s = cache.stats()
    assert s.intent_hits == 1
    assert s.intent_misses == 1


def test_semantic_hit(cache: RedisCache):
    q1 = [1.0, 0.0, 0.0]
    q2 = [0.99, 0.1, 0.0]
    cache.cache_intent_with_embedding("查北京天气", Intent(name="天气"), embedding=q1)
    got = cache.query_intent_semantic("查询北京天气怎么样", q2, threshold=0.9)
    assert got is not None
    assert got.name == "天气"


def test_semantic_below_threshold(cache: RedisCache):
    q1 = [1.0, 0.0, 0.0]
    q2 = [0.0, 1.0, 0.0]
    cache.cache_intent_with_embedding("a", Intent(name="天气"), embedding=q1)
    assert cache.query_intent_semantic("b", q2, threshold=0.9) is None
