"""chat_bot.py — 多轮对话 + 问答缓存 的最小示例。

使用前需 `pip install -e .` 安装 rediscache。
默认连接 localhost:6379；可设 FAKE_REDIS=1 改用 fakeredis 演示。
"""

import os
import time

from rediscache import Answer, CacheConfig, Message, RedisCache


def fake_llm(prompt: str) -> str:
    time.sleep(0.01)
    return f"[mock-llm] -> {prompt[:30]}"


def main():
    use_fake = os.environ.get("FAKE_REDIS") == "1"
    if use_fake:
        import fakeredis
        client = fakeredis.FakeRedis(decode_responses=True)
    else:
        import redis
        client = redis.Redis.from_url("redis://localhost:6379/0", decode_responses=True)

    config = CacheConfig(key_prefix="chatbot-demo", history_ttl=3600, qa_ttl=3600)
    cache = RedisCache(client, config=config)

    session_id = "demo-session-1"

    for turn in range(3):
        user_msg = f"第 {turn + 1} 轮：Python 是什么？"
        history = cache.query_history(session_id, limit=20)
        history.append(Message(role="user", content=user_msg))

        ans = cache.query_answer(user_msg)
        if ans is None:
            ans = Answer(content=fake_llm(user_msg), model="gpt-4")
            cache.cache_answer(user_msg, ans)
            print(f"[miss] 调 LLM -> {ans.content}")
        else:
            print(f"[hit ] 命中缓存 -> {ans.content}")

        history.append(Message(role="assistant", content=ans.content))
        cache.append_message(session_id, Message(role="user", content=user_msg))
        cache.append_message(session_id, Message(role="assistant", content=ans.content))

    final = cache.query_history(session_id)
    print(f"\n会话历史共 {len(final)} 条：")
    for m in final:
        print(f"  {m.role:10s} | {m.content}")

    print(f"\n统计：{cache.stats()}")


if __name__ == "__main__":
    main()
