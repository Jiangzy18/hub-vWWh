"""intent_router.py — 意图识别缓存的最小示例。

对相同的 query 复用缓存的 Intent 结构，避免重复调用分类 LLM。
"""

import os
import time

from rediscache import CacheConfig, Intent, RedisCache


def fake_classifier(text: str) -> Intent:
    time.sleep(0.01)
    if "天气" in text:
        return Intent(name="查天气", slots={"city": "北京"}, confidence=0.92, model="gpt-4")
    if "机票" in text:
        return Intent(name="订机票", slots={"destination": "上海"}, confidence=0.88, model="gpt-4")
    return Intent(name="闲聊", confidence=0.5, model="gpt-4")


def dispatch(intent: Intent) -> str:
    if intent.name == "查天气":
        return f"-> 路由到 weather_skill，slots={intent.slots}"
    if intent.name == "订机票":
        return f"-> 路由到 booking_skill，slots={intent.slots}"
    return "-> 路由到 chitchat_skill"


def main():
    use_fake = os.environ.get("FAKE_REDIS") == "1"
    if use_fake:
        import fakeredis
        client = fakeredis.FakeRedis(decode_responses=True)
    else:
        import redis
        client = redis.Redis.from_url("redis://localhost:6379/0", decode_responses=True)

    cache = RedisCache(client, config=CacheConfig(key_prefix="intent-demo"))

    queries = [
        "北京今天天气怎么样",
        "北京今天天气怎么样",  # 应命中
        "  北京今天天气怎么样。",  # 归一化后应命中
        "我想订一张去上海的机票",
    ]

    for q in queries:
        intent = cache.query_intent(q)
        if intent is None:
            intent = fake_classifier(q)
            cache.cache_intent(q, intent)
            print(f"[miss] classify -> {intent.name}")
        else:
            print(f"[hit ] {intent.name}")
        print(f"        {dispatch(intent)}")

    print(f"\n统计：{cache.stats()}")


if __name__ == "__main__":
    main()
