# RedisCache — LLM 应用缓存层

> 基于 Redis 的 LLM 应用统一缓存层，提供四类缓存能力 + 标准化查询接口。

---

## 1. 项目目标

为 LLM（大模型）应用提供四类高频可复用结果的本地化缓存，减少对外部 API 的重复调用，缩短响应时延，降低调用成本。

| 缓存类型 | 主要解决什么问题 | 命中后节省的代价 |
| --- | --- | --- |
| 问答内容缓存 | 相同/相似问题反复询问 LLM | 一次完整推理 + Token 费用 |
| 编码缓存 | 同一段文本反复调用 Embedding 模型 | 一次 Embedding API 调用 |
| 对话历史缓存 | 多轮对话上下文重复拉取 / 重建 | 一次 DB / 远端存储查询 |
| 意图识别结构缓存 | 相同 query 反复调用分类/抽取 LLM | 一次结构化推理 |

---

## 2. 总体架构

```
┌─────────────────────────────────────────────────────────┐
│                    Application Layer                    │
└──────────────────────────┬──────────────────────────────┘
                           │
            ┌──────────────▼──────────────┐
            │   RedisCache (统一入口)      │
            │  - query_answer              │
            │  - query_encoding            │
            │  - query_history             │
            │  - query_intent              │
            └──┬──────────┬──────────┬─────┘
               │          │          │
        ┌──────▼──┐  ┌────▼────┐ ┌───▼──────┐
        │ Q&A     │  │ Encoding│ │ History  │  ┌─────────┐
        │ Module  │  │ Module  │ │ Module   │  │ Intent  │
        │ (String │  │ (String │ │ (List /  │  │ Module  │
        │  +Hash) │  │  +Hash) │ │  Stream) │  │(String) │
        └────┬────┘  └────┬────┘ └────┬─────┘  └────┬────┘
             │            │           │             │
             └────────────┴─────┬─────┴─────────────┘
                                │
                         ┌──────▼──────┐
                         │    Redis     │
                         └──────────────┘
```

设计原则：

- **统一入口**：`RedisCache` 类对外暴露四个 `query_*` 接口，应用层不直接接触 Redis。
- **职责分离**：每个缓存模块独立，可单独替换实现（如把编码缓存切到向量库）。
- **键名空间隔离**：每个模块使用独立前缀，防止键冲突。
- **TTL + LRU 兜底**：业务 TTL + Redis `maxmemory-policy=allkeys-lru` 防止内存爆炸。

---

## 3. 缓存键设计

| 模块 | Key 模板 | Value 类型 | 默认 TTL |
| --- | --- | --- | --- |
| Q&A 缓存 | `qa:{algo}:{hash}` | String (JSON) | 24h |
| 编码缓存 | `enc:{model}:{hash}` | String (JSON array) | 30d |
| 对话历史 | `hist:{session_id}` | List / Stream | 2h（滑动续期） |
| 意图识别 | `intent:{algo}:{hash}` | String (JSON) | 7d |

- `algo` 标识归一化算法（如 `norm-v1`），便于算法升级时区分版本。
- `hash` 默认用 `sha1` 归一化后的输入；归一化策略在 §4 中定义。
- `session_id` 由调用方传入，建议使用 UUID。
- 所有查询接口都接受「禁用缓存」逃生口（`use_cache=False`），便于调试和强制刷新。

---

## 4. 归一化与 Hash 策略

`hash` 前必须对原始输入做归一化，否则 `「你好」` / `「 你好 」` / `「你好。」` 会被识别为不同 key。

```python
def normalize(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r'\s+', ' ', text)             # 合并空白
    text = re.sub(r'[。.!?,;:？!，,；：]+$', '', text)  # 去尾标点
    return text

def make_hash(text: str, algo: str = 'norm-v1') -> str:
    return hashlib.sha1(f'{algo}:{normalize(text)}'.encode('utf-8')).hexdigest()
```

可扩展点：归一化算法以版本号标识（`norm-v1`、`norm-v2`），升级时可灰度。

---

## 5. 四大缓存模块 & 查询接口

> 所有接口均为 **查询（query）语义**：传入原始输入，返回缓存结果或 `None`；命中则跳过下游 LLM/Embedding 调用。

### 5.1 问答内容缓存（Q&A Cache）

**目的**：在调用 LLM 之前先查缓存，命中直接返回答案。

**查询接口**：

```python
# 精确查询（基于归一化 + hash）
def query_answer(
    question: str,
    use_cache: bool = True,
) -> Optional[Answer]:
    """
    Args:
        question: 用户问题（原始文本）
        use_cache: 是否启用缓存，False 时直接返回 None（穿透到 LLM）

    Returns:
        Answer: 缓存命中时返回；未命中返回 None，调用方应继续走 LLM
    """

# 语义查询（基于向量相似度，需依赖 5.2 编码缓存）
async def query_answer_semantic(
    question: str,
    threshold: float = 0.92,
    top_k: int = 1,
) -> Optional[Answer]:
    """
    命中条件：缓存中存在相似度 >= threshold 的问答对。
    需要嵌入缓存中已存问题的向量；可与 5.2 共用向量检索通路。
    """
```

**写入接口**（用于 LLM 返回后回填）：

```python
def cache_answer(question: str, answer: Answer, ttl: int = 86400) -> None: ...
def cache_answer_with_embedding(question: str, answer: Answer, embedding: List[float]) -> None: ...
```

**返回结构**：

```python
@dataclass
class Answer:
    content: str
    model: str                    # 哪个模型生成的
    created_at: float             # 写入时间
    hit_count: int = 0            # 命中次数
    meta: Dict[str, Any] = ...    # tokens、latency 等
```

---

### 5.2 编码缓存（Encoding Cache）

**目的**：缓存文本向量，避免重复调用 Embedding API。

**查询接口**：

```python
def query_encoding(
    text: str,
    model: str = 'text-embedding-3-small',
    use_cache: bool = True,
) -> Optional[List[float]]:
    """
    Args:
        text: 原始文本
        model: 嵌入模型名，键中体现以支持多模型共存
        use_cache: False 时直接返回 None

    Returns:
        命中返回向量（list[float]），未命中返回 None
    """

def batch_query_encodings(
    texts: List[str],
    model: str = 'text-embedding-3-small',
) -> List[Optional[List[float]]]:
    """
    批量查询，未命中的项返回 None，调用方需自行补全。
    返回列表与输入顺序严格一致，便于按位回填。
    """
```

**写入接口**：

```python
def cache_encoding(text: str, embedding: List[float], model: str, ttl: int = 2592000) -> None: ...
def batch_cache_encodings(texts: List[str], embeddings: List[List[float]], model: str) -> None: ...
```

**典型用法**（与 5.1 语义查询配合）：

```python
emb = cache.query_encoding(q) or embed(q)
# 拿去算相似度 / 入向量库
```

---

### 5.3 对话历史缓存（Conversation History Cache）

**目的**：按 `session_id` 维护多轮对话上下文，供 prompt 组装时使用。

**存储结构**：使用 Redis `List`（轻量场景）或 `Stream`（需要严格顺序与消费位点时）。

**查询接口**：

```python
def query_history(
    session_id: str,
    limit: int = 20,
    order: Literal['asc', 'desc'] = 'asc',
    use_cache: bool = True,
) -> List[Message]:
    """
    Args:
        session_id: 会话 ID
        limit: 返回最近 N 条消息
        order: 升序（按时间正序）/ 降序（最新在前）
        use_cache: False 时穿透到持久层（如果有的话）

    Returns:
        按 order 排列的消息列表；无历史返回空列表（不要返回 None）
    """

def query_history_window(
    session_id: str,
    max_tokens: int = 4000,
) -> List[Message]:
    """
    按 token 上限滑动窗口取最近 N 条，用于 prompt 拼接。
    需要轻量 tokenizer；超长消息按比例截断。
    """
```

**写入接口**：

```python
def append_message(session_id: str, message: Message, ttl: int = 7200) -> None: ...
def clear_history(session_id: str) -> None: ...
def extend_session_ttl(session_id: str, ttl: int = 7200) -> None: ...
```

**返回结构**：

```python
@dataclass
class Message:
    role: Literal['user', 'assistant', 'system', 'tool']
    content: str
    ts: float
    meta: Dict[str, Any] = ...
```

**注意事项**：

- 每次 `append_message` 后应续期 TTL（滑动窗口语义）。
- 若超过单 session 长度上限（例如 1000 条），按 FIFO 截断。
- 严禁把含敏感信息的 system prompt 写入 —— `clear_history` 是显式逃生口。

---

### 5.4 意图识别结构缓存（Intent Recognition Cache）

**目的**：缓存 LLM / 分类器产出的意图结构（intent + slots + confidence 等），避免重复解析。

**查询接口**：

```python
def query_intent(
    text: str,
    schema_version: str = 'v1',
    use_cache: bool = True,
) -> Optional[Intent]:
    """
    Args:
        text: 用户原始输入
        schema_version: 意图结构 schema 版本，跨版本隔离防止解析失败
        use_cache: False 时直接返回 None

    Returns:
        命中返回结构化意图；未命中返回 None，调用方应继续走识别流程
    """

async def query_intent_semantic(
    text: str,
    threshold: float = 0.90,
    schema_version: str = 'v1',
) -> Optional[Intent]:
    """
    语义命中：缓存中存在相似度 >= threshold 的同 schema_version 意图。
    与 5.2 编码缓存共用嵌入通路。
    """
```

**写入接口**：

```python
def cache_intent(text: str, intent: Intent, schema_version: str = 'v1', ttl: int = 604800) -> None: ...
def cache_intent_with_embedding(text: str, intent: Intent, embedding: List[float], schema_version: str) -> None: ...
```

**返回结构**：

```python
@dataclass
class Intent:
    name: str                                # 意图名，如 "查询天气"
    slots: Dict[str, Any]                    # 槽位，如 {"city": "北京"}
    confidence: float                        # 置信度
    schema_version: str                      # 结构 schema 版本
    model: str                               # 识别所用模型
    created_at: float
    meta: Dict[str, Any] = ...
```

**schema_version 的作用**：当业务升级意图结构（如新增 slot）时，旧缓存不会污染新解析器；旧 key 通过 TTL 自然淘汰。

---

## 6. 统一入口类设计

```python
class RedisCache:
    def __init__(self, redis_client, config: CacheConfig): ...

    # —— 4 个查询接口（应用层只调这 4 个）——
    def query_answer(self, question: str, **kwargs) -> Optional[Answer]: ...
    def query_encoding(self, text: str, **kwargs) -> Optional[List[float]]: ...
    def query_history(self, session_id: str, **kwargs) -> List[Message]: ...
    def query_intent(self, text: str, **kwargs) -> Optional[Intent]: ...

    # —— 写入接口（命中下游 LLM 后回填时使用）——
    def cache_answer(self, question: str, answer: Answer) -> None: ...
    def cache_encoding(self, text: str, embedding: List[float]) -> None: ...
    def append_message(self, session_id: str, message: Message) -> None: ...
    def cache_intent(self, text: str, intent: Intent) -> None: ...

    # —— 运维接口 ——
    def invalidate(self, key: str) -> None: ...
    def stats(self) -> CacheStats: ...
    def health(self) -> bool: ...
```

`CacheConfig` 集中放所有 TTL、归一化算法、key 前缀等可调参数；不允许在业务代码中散落魔法值。

---

## 7. 配置（CacheConfig）

```python
@dataclass
class CacheConfig:
    redis_url: str

    # 键前缀，便于多环境/多租户隔离
    key_prefix: str = 'rc'

    # 各模块默认 TTL（秒）
    qa_ttl: int = 86400            # 1 天
    encoding_ttl: int = 2592000    # 30 天
    history_ttl: int = 7200        # 2 小时（滑动续期）
    intent_ttl: int = 604800       # 7 天

    # 归一化算法版本
    normalize_algo: str = 'norm-v1'

    # 单 session 最大消息数
    max_history_len: int = 1000

    # 全局开关
    enabled: bool = True
    # 调试用：可单独禁用某个模块
    enable_qa: bool = True
    enable_encoding: bool = True
    enable_history: bool = True
    enable_intent: bool = True
```

---

## 8. 典型使用流程

### 8.1 问答（最常见）

```python
answer = cache.query_answer(question)
if answer is None:
    answer = await llm.ask(question)
    cache.cache_answer(question, answer)
return answer
```

### 8.2 语义问答（带相似度匹配）

```python
answer = await cache.query_answer_semantic(question, threshold=0.92)
if answer is None:
    answer = await llm.ask(question)
    emb = await embed(question)
    cache.cache_answer_with_embedding(question, answer, emb)
return answer
```

### 8.3 多轮对话

```python
history = cache.query_history(session_id, limit=20)
history.append(Message(role='user', content=q, ts=time.time()))
reply = await llm.chat(history)
history.append(Message(role='assistant', content=reply, ts=time.time()))

cache.append_message(session_id, history[-2])
cache.append_message(session_id, history[-1])
```

### 8.4 意图识别

```python
intent = cache.query_intent(text)
if intent is None:
    intent = await llm.classify(text)
    cache.cache_intent(text, intent)
dispatch(intent)
```

---

## 9. 命中率观测

每个模块的查询/写入都要打点（可使用 Redis `INFO commandstats` 或应用层 metrics）：

| 指标 | 说明 |
| --- | --- |
| `qa.hit / qa.miss` | 问答缓存命中次数 |
| `encoding.hit / encoding.miss` | 编码缓存命中次数 |
| `intent.hit / intent.miss` | 意图缓存命中次数 |
| `history.queries` | 历史查询次数（无 hit/miss 之分） |
| `latency.{module}.p50/p95` | 各模块查询时延 |

建议暴露为 Prometheus 指标；命中率长期 < 20% 时应排查归一化或 TTL 设置。

---

## 10. 边界与不做的事

- **不做分布式锁**：本模块假设单写多读；强一致需求应在更上层处理。
- **不做向量检索本体**：本模块只缓存「已知答案 + 向量」，向量索引由专用向量库承担。
- **不写敏感数据**：调用方有义务在写入前脱敏；本模块不做审计与脱敏。
- **不做自动预热**：缓存冷启动由调用方决定是否预热。

---

## 11. 目录建议

```
rediscache/
├── CLAUDE.md                # 本文件
├── pyproject.toml / package.json
├── src/
│   ├── redis_cache.py       # RedisCache 统一入口
│   ├── config.py            # CacheConfig
│   ├── normalize.py         # 归一化 & hash
│   ├── modules/
│   │   ├── qa.py
│   │   ├── encoding.py
│   │   ├── history.py
│   │   └── intent.py
│   └── types.py             # Answer / Message / Intent
├── tests/
│   ├── test_qa.py
│   ├── test_encoding.py
│   ├── test_history.py
│   └── test_intent.py
└── examples/
    ├── chat_bot.py
    └── intent_router.py
```

---

## 12. 待办（首次实现时按此顺序）

1. 落 `CacheConfig` + `normalize` + 键模板
2. 实现 `query_encoding` / `cache_encoding`（最简单，先打通）
3. 实现 `query_history` / `append_message`（最常用）
4. 实现 `query_intent` / `cache_intent`
5. 实现 `query_answer`（精确 + 语义两种模式）
6. 加命中率 metrics
7. 补 tests
